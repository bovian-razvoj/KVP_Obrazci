﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KVP_Obrazci.Domain.Models
{
    public class KVPInfoUserModel
    {
        public decimal PodaniKVP { get; set; }
        public decimal PlanKVP { get; set; }
        public decimal OdstotekKVP { get; set; }
    }
}